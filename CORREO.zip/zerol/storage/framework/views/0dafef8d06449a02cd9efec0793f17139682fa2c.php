Hola <?php echo e($name); ?>


Activa <a href="<?php echo e(url('/activacion/'.$code)); ?>">aqui</a> <?php echo e($code); ?>