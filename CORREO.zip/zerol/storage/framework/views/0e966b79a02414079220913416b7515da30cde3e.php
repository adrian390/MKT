<?php $__env->startComponent('mail::message'); ?>


Hola!



Está recibiendo este correo electrónico porque recibimos una solicitud de restablecimiento de contraseña para su cuenta.


<?php if(isset($actionText)): ?>
<?php
    switch ($level) {
        case 'success':
            $color = 'green';
            break;
        case 'error':
            $color = 'red';
            break;
        default:
            $color = 'blue';
    }
?>
<?php $__env->startComponent('mail::button', ['url' => $actionUrl, 'color' => $color]); ?>
Cambiar Contraseña
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>



Si no solicitó un restablecimiento de contraseña, no es necesario realizar ninguna otra acción.

<?php if(! empty($salutation)): ?>
<?php echo e($salutation); ?>

<?php else: ?>
Saludos,<br><?php echo e(config('app.name')); ?>

<?php endif; ?>


<?php if(isset($actionText)): ?>
<?php $__env->startComponent('mail::subcopy'); ?>

Si tienes problemas para hacer clic en el botón "Restablecer contraseña", copia y pega la URL a continuación en tu navegador web:  [<?php echo e($actionUrl); ?>](<?php echo $actionUrl; ?>)
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
