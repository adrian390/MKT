Bienvenido(a), <?php echo e($name); ?>


por favor activa tu cuenta dando click <a href="<?php echo e(url('/login')); ?>">AQUI</a>, Tu contraseña por defecto es <?php echo e($password); ?> Gracias