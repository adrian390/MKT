<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="modal-dialog text-center">
                 <div class="modal-content">

                <div class="col-12 user-img">
                    <img src="<?php echo e(asset('img/user.png')); ?>">
                </div>

                <div class="panel-heading"><h1 class="mb-5">Registro</h1></div>

                <div class="panel-body">

                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        

                       <?php if($message = Session::get('success')): ?>
                          <div class="alert alert-success">
                            <p>
                              <?php echo e($message); ?>

                            </p>
                          </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('warning')): ?>
                          <div class="alert alert-warning">
                            <p>
                              <?php echo e($message); ?>

                            </p>
                          </div>
                        <?php endif; ?>

                        <div class="grup form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Nombre</label>

                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="nombres" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                           <div class="grup form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
                            <label for="apellido" class="col-md-4 control-label">Apellidoss</label>

                            <div class="col-md-6">
                                <input id="apellido" type="text" placeholder="apellido" class="form-control" name="apellido" value="<?php echo e(old('apellido')); ?>" required autofocus>

                                <?php if($errors->has('apellido')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                          <div class="grup form-group<?php echo e($errors->has('edad') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Edad</label>

                            <div class="col-md-6">
                                <input id="edad" type="text" placeholder="edad" class="form-control" name="edad" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('edad')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('edad')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                          <div class="grup form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
                            <label for="telefono" class="col-md-4 control-label">Telefono</label>

                            <div class="col-md-6">
                                <input id="telefono" type="text" placeholder="telefono" class="form-control" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus>

                                <?php if($errors->has('telefono')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>



                          <div class="grup form-group<?php echo e($errors->has('direccion') ? ' has-error' : ''); ?>">
                            <label for="direccion" class="col-md-4 control-label">Direccion</label>

                            <div class="col-md-6">
                                <input id="direccion" type="text" placeholder="direccion" class="form-control" name="direccion" value="<?php echo e(old('direccion')); ?>" required autofocus>

                                <?php if($errors->has('direccion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>



                        <div class="grup form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-mail</label>

                            <div class="col-md-6">
                                <input id="email" type="email" placeholder="e-mail" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrarse
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>