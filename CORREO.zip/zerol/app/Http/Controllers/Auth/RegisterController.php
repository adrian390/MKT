<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Mail;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
  

 protected $redirectTo = '/register'; 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */

    //FUNCION GENERA CODIGO ALEATORIO

    function generarCodigo($longitud){
        $key = '';
        $pattern = '123456789abcdefghijklmnopqrstuvwxyz';
        $max = strlen($pattern)-1;
        for($i=0;$i<$longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
        return $key;
    }
    //FIN DE LA FUNCION

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:255',
            'apellido' => 'required|string|max:255',
            'edad' => 'required|integer',
            'telefono' => 'required|integer',
            'direccion' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $code = $this->generarCodigo(6);
        $email = $data['email'];
        $dates = array('name'=> $data['name'],'apellido'=> $data['apellido'],'edad'=> $data['edad'],'telefono'=> $data['telefono'],'direccion'=> $data['direccion'],'password' => $code);
        $this->Email($dates,$email);
        return User::create([
            'name' => $data['name'],
            'apellido' => $data['apellido'],
            'edad' => $data['edad'],
            'telefono' => $data['telefono'],
            'direccion' => $data['direccion'],
            'email' => $data['email'],
            'password' => bcrypt($code),

        ]);
    }




function Email($dates,$email){
    Mail::send('emails.plantilla',$dates, function($message) use ($email){
        $message->subject('Bienvenido(a) a Clinica Doctor Campos');
        $message->to($email);
        $message->from('campos@clinica.com','Administracion Clinica Campos');

    });
    //MENSAJE
    return redirect()->to('register')->with('success',"Enviamos el código de activación y contraseña. Por favor revise su correo.");
}
}
