@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="modal-dialog text-center">
            <div class="modal-content">
                <div class="panel-heading"><h1 class="mb-5">SISTEMA</h1></div>
                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    USTED A ENTRADO AL SISTEMA CLINICA DOCTOR CAMPOS.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
