Bienvenido(a), {{$name}}

por favor activa tu cuenta dando click <a href="{{url('/login')}}">AQUI</a>, Tu contraseña por defecto es {{$password}} Gracias